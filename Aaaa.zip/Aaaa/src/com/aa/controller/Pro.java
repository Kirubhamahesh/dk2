package com.aa.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.aa.model.Details;
import com.aa.service.DService;
@Controller
public class Pro {
	@Autowired
	DService service;
	@RequestMapping(value="/", method=RequestMethod.GET)
	public String start(Model model)
	{
		model.addAttribute("details", new Details());
		return "welcome";
	}
	
	@RequestMapping(value="data", method=RequestMethod.POST)
	public String form(@ModelAttribute("details") Details ob)
	{
		service.insert(ob);
		return "welcome";
	}

}
