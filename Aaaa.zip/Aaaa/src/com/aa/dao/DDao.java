package com.aa.dao;

import com.aa.model.Details;

public interface DDao {
	void insert(Details ob);

}
