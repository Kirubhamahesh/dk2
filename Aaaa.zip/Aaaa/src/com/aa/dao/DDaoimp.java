package com.aa.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aa.model.Details;

@Repository
public class DDaoimp implements DDao {
	@Autowired
	SessionFactory fact;
	@Override
	public void insert(Details ob)
	{
		Session session=fact.getCurrentSession();
		session.saveOrUpdate(ob);
	}
}
