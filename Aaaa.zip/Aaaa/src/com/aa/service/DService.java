package com.aa.service;

import com.aa.model.Details;

public interface DService {
	void insert(Details ob);
}
