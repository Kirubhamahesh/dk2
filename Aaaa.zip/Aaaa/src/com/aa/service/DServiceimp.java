package com.aa.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.aa.dao.DDao;
import com.aa.model.Details;

@Service
public class DServiceimp implements DService {
	@Autowired
	DDao dao;
	@Override
	@Transactional
	public void insert(Details ob)
	{
		dao.insert(ob);
	}
	
	

}
